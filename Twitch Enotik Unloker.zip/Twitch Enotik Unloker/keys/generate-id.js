const crypto = require('crypto');
const fs = require('fs');
const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const pubDer = publicKey.export({ type: 'spki', format: 'der' });
const privPem = privateKey.export({ type: 'pkcs8', format: 'pem' });
fs.writeFileSync('keys/private.pem', privPem);
fs.writeFileSync('keys/public.der', pubDer);
const b64 = pubDer.toString('base64');
fs.writeFileSync('keys/public.b64', b64);
const hash = crypto.createHash('sha256').update(pubDer).digest();
const bytes = hash.subarray(0, 16);
let id = '';
for (const byte of bytes) {
  id += String.fromCharCode(97 + (byte >> 4));
  id += String.fromCharCode(97 + (byte & 0x0f));
}
console.log('NEW_EXTENSION_ID=' + id);
console.log('PUBLIC_KEY_BASE64=' + b64);
fs.writeFileSync('keys/new-id.txt', id + '\n');
